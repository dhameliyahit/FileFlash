function analyzeText() {
    const text = document.getElementById('inputText').value;
    const charCount = text.length;
    const wordCount = text.split(/\s+/).filter(word => word.length > 0).length;
    const sentenceCount = text.split(/[.!?]+/).filter(sentence => sentence.trim().length > 0).length;
    const digitCount = text.replace(/[^0-9]/g, '').length;
    const vowelCount = text.match(/[aeiou]/gi) ? text.match(/[aeiou]/gi).length : 0;
    const consonantCount = text.match(/[bcdfghjklmnpqrstvwxyz]/gi) ? text.match(/[bcdfghjklmnpqrstvwxyz]/gi).length : 0;

    const results = `
        <p>Character count: ${charCount}</p>
        <p>Word count: ${wordCount}</p>
        <p>Sentence count: ${sentenceCount}</p>
        <p>Digit count: ${digitCount}</p>
        <p>Vowel count: ${vowelCount}</p>
        <p>Consonant count: ${consonantCount}</p>
    `;

    document.getElementById('results').innerHTML = results;
}

function convertToUppercase() {
    const text = document.getElementById('inputText').value;
    document.getElementById('inputText').value = text.toUpperCase();
}

function convertToLowercase() {
    const text = document.getElementById('inputText').value;
    document.getElementById('inputText').value = text.toLowerCase();
}

function formatText() {
    const text = document.getElementById('inputText').value;
    const formattedText = text.replace(/\s+/g, ' ').trim();
    document.getElementById('inputText').value = formattedText;
}

function copyText() {
    const text = document.getElementById('inputText').value;
    navigator.clipboard.writeText(text);
    alert('Text copied to clipboard');
}

function clearText() {
    document.getElementById('inputText').value = '';
    document.getElementById('results').innerHTML = '';
}
